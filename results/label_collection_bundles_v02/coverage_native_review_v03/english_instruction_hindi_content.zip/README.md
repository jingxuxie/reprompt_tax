# RePromptTax v0.3 Coverage Native-Review Bundle

Slice: English Instruction, Hindi Content

Files:

- `review_sheet.html`: preferred local browser interface.
- `slice_packet.csv`: equivalent CSV packet if you prefer spreadsheet editing.
- `review_instructions.md`: labeling rules and issue-type codes.

Use the reviewer ID assigned in the roster. Fill every TRUE/FALSE field. If any
component is FALSE, include the matching issue type. Export or save the
completed CSV as `coverage_native_review_v03_english_instruction_hindi_content_completed.csv`.

This bundle intentionally excludes model-output scores and automatic labels.
