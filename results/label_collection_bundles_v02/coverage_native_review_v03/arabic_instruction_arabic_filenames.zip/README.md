# RePromptTax v0.3 Coverage Native-Review Bundle

Slice: Arabic Instruction, Arabic Content With English File Names

Files:

- `review_sheet.html`: preferred local browser interface.
- `slice_packet.csv`: equivalent CSV packet if you prefer spreadsheet editing.
- `review_instructions.md`: labeling rules and issue-type codes.

Use the reviewer ID assigned in the roster. Fill every TRUE/FALSE field. If any
component is FALSE, include the matching issue type. Export or save the
completed CSV as `coverage_native_review_v03_arabic_instruction_arabic_filenames_completed.csv`.

This bundle intentionally excludes model-output scores and automatic labels.
