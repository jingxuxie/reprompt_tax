# v0.3 Coverage Native-Review Instructions

Mark `reviewer_release_usable` TRUE only when all component labels are TRUE.

Issue-type mapping:

- `reviewer_prompt_clear` FALSE -> `ambiguous_instruction`
- `reviewer_target_language_natural` FALSE -> `unnatural_target_text`
- `reviewer_script_expectation_valid` FALSE -> `script_expectation_problem`
- `reviewer_preservation_spans_valid` FALSE -> `preservation_span_problem`
- `reviewer_known_bad_outputs_valid` FALSE -> `known_bad_output_problem`

Do not list an issue type for a component marked TRUE. Use `other` only with a
short note.
