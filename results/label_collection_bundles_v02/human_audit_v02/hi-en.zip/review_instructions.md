# Human Audit Instructions

Mark `human_pass` TRUE only when all component labels are TRUE.

Failure-type mapping:

- `human_language_pass` FALSE -> `wrong_output_language`
- `human_script_pass` FALSE -> `script_mismatch`
- `human_preservation_pass` FALSE -> `preservation_failure`
- `human_task_pass` FALSE -> `task_noncompletion`
- `human_register_locale_pass` FALSE -> `register_locale_mismatch`

Do not list a failure type for a component marked TRUE. Use `other` only with a
short note.
