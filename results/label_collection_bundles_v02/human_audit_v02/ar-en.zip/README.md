# RePromptTax Human Audit Bundle

Slice: Arabic-English

Files:

- `review_sheet.html`: preferred local browser interface.
- `slice_packet.csv`: equivalent CSV packet if you prefer spreadsheet editing.
- `review_instructions.md`: labeling rules and failure-type codes.

Use the reviewer or annotator ID assigned in the roster. Fill every TRUE/FALSE
field. If any component is FALSE, include the matching failure type. Export or
save the completed CSV as `human_audit_packet_v0.2_ar-en_completed.csv`.

This bundle intentionally excludes private answer keys, model names, prompt
conditions, and automatic labels.
